package handler

import "testing"

func TestGetHello(t *testing.T) {

}
